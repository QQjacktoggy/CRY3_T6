"""T6.9a shallow counter-trend floor (PR #42, main 3426e10): build a NEW stage for t69_manual_install.py.

Writes only inside <root>/prediction/<stage> (must not exist). Never stops a
service and never touches the live release or any database. Usage:
  $PY -B t6s_stage_build.py --root /home/jack_shih/cry3 --overlay <dir> --stage t69-release-staged-t6s-v1-20261008
"""
import argparse, hashlib, json, runpy, shutil, sys
from pathlib import Path

PARENT = 'c2e8cfcddbdddd1bb55c0271e4f47e18decaf5117ca3bb96724e21ce2d607749'  # live v6.9.6 + PR #38
RELEASE = 'src/gridbot/prediction/release.py'
MANIFEST, PIN = 'prediction/release-manifest.json', 'prediction/release-pin.env'
P = 'src/gridbot/prediction/'
# sha256 at main 7d379b6 (what the live VM must hold; same as c0ff995) and at main 3426e10 (new).
BEFORE = {
    P+'regime_t69a_policy.py': 'a49146be700cc50cede3705f6237964d71e9ba80ad20c582b89a3f7c41665afd',
    P+'regime_t69a_bridge.py': '28ee8c32b6adabae2f3e54e67ce527903fab2914cafa90450ffe777d566f2aa7',
    P+'regime_t69a_report.py': '4ccdc093baea85903c253564da6324ed393bc3438aa8dc8712a0d3028d355e5c',
    P+'release.py': '96cb3aea2a89b0eab44e947297e7d1c85c8bc8d683835611bf413b2c22866965',
}
AFTER = {
    P+'regime_t69a_policy.py': 'd627021479eef6ecd9532e34b532dd8448a9dc30739a201d0472517a5214fd96',
    P+'regime_t69a_bridge.py': 'd890155591d627cad2381c7f31ff48e25df0ec9fd30e611f4c59743b1574df17',
    P+'regime_t69a_report.py': 'cd3804c747b34da753d6619b93a5a877eff30e7c6666442143ebab1d9572b512',
    P+'release.py': 'c5b4fa9b0472b6bd7920adcbcaa0cc594ba5ae3c3309d2f865e30416ac4dd79e',
    P+'regime_t69a_shallow_filter.py': 'd1413d26e2df359a5e51d6da06f52184e9df725d9a7f0d3e6d3c4674cb5b77a0',
}
ADDED = {P+'regime_t69a_shallow_filter.py': P+'regime_t69a_report.py'}  # new file -> sibling whose mode it takes


def sha(b):
    return hashlib.sha256(b).hexdigest()


def fingerprint(entries):
    return sha(json.dumps(entries, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True)
    ap.add_argument('--overlay', required=True)
    ap.add_argument('--stage', required=True)
    ap.add_argument('--parent', default=PARENT)
    a = ap.parse_args()
    root, overlay = Path(a.root).resolve(), Path(a.overlay).resolve()
    if not a.stage.startswith('t69-release-staged-') or '/' in a.stage:
        sys.exit('stage must be a plain t69-release-staged-* name')
    stage = root / 'prediction' / a.stage
    # 1. Read-only checks before writing anything.
    live = json.loads((root / MANIFEST).read_text())
    if live['release_fingerprint'] != a.parent or fingerprint(live['files']) != a.parent:
        sys.exit('live manifest is not the expected parent ' + a.parent)
    for row in live['files']:
        if sha((root / row['path']).read_bytes()) != row['sha256']:
            sys.exit('live file differs from live manifest: ' + row['path'])
    listed = {row['path'] for row in live['files']}
    for path, want in BEFORE.items():
        if path not in listed:
            sys.exit('not in live manifest: ' + path)
        if sha((root / path).read_bytes()) != want:
            sys.exit('live file is not main 7d379b6: ' + path)
    for path in ADDED:
        if path in listed or (root / path).exists():
            sys.exit('new file already present on VM: ' + path)
    for path, want in AFTER.items():
        if sha((overlay / path).read_bytes()) != want:
            sys.exit('overlay file hash mismatch: ' + path)
    if stage.exists():
        sys.exit('stage already exists: ' + str(stage))
    # 2. Writes, all inside the new stage directory.
    stage.mkdir()
    try:
        for row in live['files']:
            dest = stage / row['path']
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(root / row['path'], dest)
        for path in AFTER:
            dest = stage / path
            dest.write_bytes((overlay / path).read_bytes())
            dest.chmod((root / ADDED.get(path, path)).stat().st_mode & 0o777)  # keep the live file's mode
        # 3. Recompute with the stage's new release.py; no trading module is imported.
        rel = runpy.run_path(str(stage / RELEASE))
        manifest = rel['build_release_manifest'](stage)
        old = {r['path']: r['sha256'] for r in live['files']}
        new = {r['path']: r['sha256'] for r in manifest['files']}
        changed = sorted(p for p in new if new[p] != old.get(p))
        if set(new) != set(old) | set(ADDED) or changed != sorted(AFTER):
            raise RuntimeError('unexpected manifest delta: ' + repr(changed))
        (stage / MANIFEST).write_text(json.dumps(manifest, indent=2) + '\n')
        (stage / PIN).write_text('PREDICTION_EXPECTED_RELEASE_FINGERPRINT=' + manifest['release_fingerprint'] + '\n')
        problems = rel['verify_release_manifest'](stage, manifest, pin_path=stage / PIN)
        if problems:
            raise RuntimeError('stage release.py rejects its manifest: ' + repr(problems))
        fp = manifest['release_fingerprint']
        candidate = {'version': '6.9.8', 'parent': a.parent, 'expected_fingerprint': fp,
                     'files': [{'path': p, 'before': old.get(p), 'after': new[p]} for p in changed]}
        (stage / 'candidate.json').write_text(json.dumps(candidate, indent=2) + '\n')
        validation = {'status': 'STAGED_VERIFIED_NOT_DEPLOYED', 'version': '6.9.8', 'source': 'main 3426e10 (PR #42)',
                      'parent': a.parent, 'fingerprint': fp, 'changed': changed,
                      'policy_fingerprint': '129fbf0ce8120df928df9bd370fc6e5a038a0f9b4225d4cd118e7621d211ba8d',
                      'tests': 'PR #42 head 135f13f: 2399 passed, 1 skipped; CI green'}
        (stage / 'validation.json').write_text(json.dumps(validation, indent=2) + '\n')
    except BaseException:
        shutil.rmtree(stage)  # only the directory this run created
        raise
    print(json.dumps(dict(stage=str(stage), files=len(manifest['files']), parent=a.parent,
                          fingerprint=fp, changed=changed), indent=2))


if __name__ == '__main__':
    main()
